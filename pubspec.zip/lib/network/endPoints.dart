
class APIUrls {
  static const String baseUrls = 'https://ajanitech.com/test/chat-app-x/';


}
